﻿using System;
using System.Windows;
using Microsoft.Phone.Controls;
using Scoreloop.CoreSocial.API;
using Scoreloop.CoreSocial.API.Model;

namespace ScoreloopEnabled_WindowsPhoneApplication
{
    public partial class MainPage : PhoneApplicationPage
    {
        private IScoresController _scoresController;
        private const int Mode = 0;
        private const int OnPage = 25;

        // Constructor
        public MainPage()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        // Load data for the ViewModel Items
        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            App.slClient.Session.Authenticated += SessionAuthenticated;
            App.slClient.UnexpectedExceptionUnhandled += UnexpectedExceptionUnhandled;

            UpdateAuthenticatedUser(App.slClient.Status.IsSessionAuthenticated ? App.slClient.Session.User : null);
            PrepareInfoScreen(App.slClient);
        }

       private void btnAuth_Click(object sender, RoutedEventArgs e)
        {
            if (App.slClient.Status.IsSessionAuthenticated)
                return;

            var sessionController = App.slClient.CreateSessionController();
            sessionController.RequestFailed += SessionController_RequestFailed;
            sessionController.RequestCancelled += SessionController_RequestFailed;
            // not subscribing to SessionAuthenticated, as this is already monitored
            // via App.slClient.Session.Authenticated event handler...

            sessionController.Authenticate();
            txtStatus.Text = "Authenticating...";
        }

        void SessionAuthenticated(object sender, SessionEventArgs e)
        {
            UpdateAuthenticatedUser(e.Session.User);
            UpdateSessionState(e.Session);
        }

        void UpdateAuthenticatedUser(User user)
        {
            if (user != null)
                txtStatus.Text = string.Concat("Welcome back ", user.Login, "!");
            else
                txtStatus.Text = "Not authenticated yet!";
        }

        void UpdateSessionState(Session session)
        {
            txtSessionStatus.Text = session.IsAuthenticated ? "Authenticated" : "Not authenticated";
            txtUserStatus.Text = session.IsAuthenticated ? session.User.Login : "unknown";
        }

        void UnexpectedExceptionUnhandled(object sender, UnexpectedExceptionEventArgs e)
        {
            txtSessionStatus.Text = e.Exception.Message;
            txtStatus.Text = e.Exception.Message;
            txtUserStatus.Text = e.Exception.Message;
        }

        void SessionController_RequestFailed(object sender, RequestControllerEventArgs<IRequestController> e)
        {
            if (e.Error.Status == StatusCode.NotFound)
                txtStatus.Text = "Invalid Internet connection";
            else
                txtStatus.Text = e.Error.ToString();

            UpdateSessionState(e.Controller.Session);
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            CreateScoresControllerIfNeeded();

            if (_scoresController.IsProcessing)
                return;

            _scoresController.LoadScores(_scoresController.GlobalSearchList, new Range(0, OnPage), Mode);
        }

        private void btnLoadPrevious_Click(object sender, RoutedEventArgs e)
        {
            CreateScoresControllerIfNeeded();

            if (_scoresController.IsProcessing)
                return;

            _scoresController.LoadPreviousRange();
        }

        private void btnLoadNext_Click(object sender, RoutedEventArgs e)
        {
            CreateScoresControllerIfNeeded();

            if (_scoresController.IsProcessing)
                return;

            _scoresController.LoadNextRange();
        }

        void CreateScoresControllerIfNeeded()
        {
            if (_scoresController == null)
            {
                _scoresController = App.slClient.CreateScoresController();
                _scoresController.RequestFailed += ScoresController_RequestFailed;
                _scoresController.RequestCancelled += ScoresController_RequestFailed;
                _scoresController.ScoresLoaded += ScoresController_ScoresLoaded;
            }
        }

        void ScoresController_RequestFailed(object sender, RequestControllerEventArgs<IRequestController> e)
        {
            MessageBox.Show(e.Error.ToString());
        }

        void ScoresController_ScoresLoaded(object sender, RequestControllerEventArgs<IScoresController> e)
        {
            DataContext = _scoresController.Scores;
            btnLoad.Visibility = _scoresController.HasPreviousRange || _scoresController.HasNextRange ? Visibility.Collapsed : Visibility.Visible;
            btnLoadNext.Visibility = _scoresController.HasNextRange ? Visibility.Visible : Visibility.Collapsed;
            btnLoadPrev.Visibility = _scoresController.HasPreviousRange ? Visibility.Visible : Visibility.Collapsed;
        }

        void PrepareInfoScreen(ScoreloopClient client)
        {
            txtClientVersion.Text = string.Concat("v", client.Version, " (", client.Platform, ")");
            UpdateAuthenticatedUser(client.Session.User);
            UpdateSessionState(client.Session);
        }

    }
}