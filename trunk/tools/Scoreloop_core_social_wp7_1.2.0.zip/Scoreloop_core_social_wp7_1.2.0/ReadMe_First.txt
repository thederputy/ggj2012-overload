==============================
Scoreloop Windows Phone OS SDK
==============================

Thanks for downloading this Scoreloop Windows Phone OS SDK.

This SDK contains all the needed sources, libraries, assets and documentation to get you started
making your game socially enabled quickly and successfully.


Package contents:
=================

- CoreSocial/
			Contains the core library needed for every Scoreloop enabled game. 
			Refer to IntegrationGuide.pdf and Installation.txt for more details, how to get started.

- SampleWindowsPhoneApplication/
			A sample application showing how to integrate Scoreloop CoreSocial into a game.

- Docs/		Reference documentation in CHM format for Scoreloop Core Social API.

- BrandingAssets/
			Icons you might want to use to mark your game as Scoreloop enabled.

- ChangeLog*.txt
			Release notes and API-change documents.

- BrandingGuidelines.pdf the accompanying document describing how to use the branding assets.

- LicenseAgreement.pdf	the license this software ships with. 


What to read next:
==================

Start by reading the ChangeLog.txt file as it contains a summary of what is new in this release.

If you are new to Scoreloop, open IntegrationGuide.pdf or documentation directly from Docs/Scoreloop.CoreSocial.documentation.chm.


Want to get hands on?
=====================

The easiest way to experience the Scoreloop SDK is to run the demo application (SampleWindowsPhoneApplication) on your device.


How to include Scoreloop into your own game?
============================================

You can look at how things are set up for the demo applications and follow the approach with your game.
Generally, add the necessary Scoreloop.CoreSocial.dll as a reference to your project and instanciate ScoreloopClient object.

To get all parameters required by ScoreloopClient, go to http://developer.scoreloop.com, create a game at our server
and copy them from "Game Overview" section.

Have a look at the Docs folder for more information on how to set up your game for Scoreloop integration.


Where to get additional help:
=============================

You will find more help and documentation on the web at http://developer.scoreloop.com and in our support forum
which is located at http://support.scoreloop.com


We wish you big success with your Scoreloop enabled games!

===================
Your Scoreloop Team
===================
